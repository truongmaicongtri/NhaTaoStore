var items = [{
        name: "IPhone 11",
        imageUrl: [
            "img/showcase/item1.jpg",
            "img/showcase/item2.jpg",
            "img/showcase/item3.jpg",
            "img/showcase/item4.jpg"
        ],
        category: "iphone",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "IPhone 11 Pro",
        imageUrl: [
            "img/showcase/item2.jpg",
            "img/showcase/item2.jpg",
            "img/showcase/item3.jpg",
            "img/showcase/item4.jpg"
        ],
        category: "iphone",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "IPhone 11 Pro Max",
        imageUrl: [
            "img/showcase/item3.jpg",
            "img/showcase/item2.jpg",
            "img/showcase/item3.jpg",
            "img/showcase/item4.jpg"
        ],
        category: "iphone",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "Iphone 9",
        imageUrl: [
            "img/showcase/item4.jpg",
            "img/showcase/item2.jpg",
            "img/showcase/item3.jpg",
            "img/showcase/item4.jpg"
        ],
        category: "iphone",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "IPhone 8 Plus",
        imageUrl: [
            "img/showcase/item1.jpg",
            "img/showcase/item2.jpg",
            "img/showcase/item3.jpg",
            "img/showcase/item4.jpg"
        ],
        category: "iphone",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "IPhone 8",
        imageUrl: [
            "img/showcase/item2.jpg",
            "img/showcase/item2.jpg",
            "img/showcase/item3.jpg",
            "img/showcase/item4.jpg"
        ],
        category: "iphone",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "Iphone 7 Plus",
        imageUrl: [
            "img/showcase/item3.jpg",
            "img/showcase/item2.jpg",
            "img/showcase/item3.jpg",
            "img/showcase/item4.jpg"
        ],
        category: "iphone",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "Iphone 6S Plus",
        imageUrl: [
            "img/showcase/item4.jpg",
            "img/showcase/item3.jpg",
            "img/showcase/item1.jpg",
            "img/showcase/item2.jpg"
        ],
        category: "iphone",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "IPad Pro",
        imageUrl: [
            "img/showcase/ipad3.jpg",
            "img/showcase/ipad2.jpg",
            "img/showcase/ipad3.jpg",
            "img/showcase/ipad4.jpg"
        ],
        category: "ipad",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "IPad Air",
        imageUrl: [
            "img/showcase/ipad1.jpg",
            "img/showcase/ipad2.jpg",
            "img/showcase/ipad3.jpg",
            "img/showcase/ipad4.jpg"
        ],
        category: "ipad",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "Macbook Pro 2016",
        imageUrl: [
            "img/showcase/macbook1.jpg",
            "img/showcase/macbook2.jpg",
            "img/showcase/macbook3.jpg",
            "img/showcase/macbook4.jpg"
        ],
        category: "macbook",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "Macbook Pro 2017",
        imageUrl: [
            "img/showcase/macbook2.jpg",
            "img/showcase/macbook2.jpg",
            "img/showcase/macbook3.jpg",
            "img/showcase/macbook4.jpg"
        ],
        category: "macbook",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "Macbook pro 2018",
        imageUrl: [
            "img/showcase/macbook3.jpg",
            "img/showcase/macbook2.jpg",
            "img/showcase/macbook3.jpg",
            "img/showcase/macbook4.jpg"
        ],
        category: "macbook",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
    {
        name: "Macbook Pro 2019",
        imageUrl: [
            "img/showcase/macbook4.jpg",
            "img/showcase/macbook2.jpg",
            "img/showcase/macbook3.jpg",
            "img/showcase/macbook4.jpg"
        ],
        category: "macbook",
        prices: [{
                "color": "Đỏ",
                "storage": "64GB",
                "price": "15.100.000",
            },
            {
                "color": "Vàng",
                "storage": "64GB",
                "price": "15.200.000",
            },
            {
                "color": "Xanh",
                "storage": "64GB",
                "price": "15.300.000",
            },
            {
                "color": "Tím",
                "storage": "64GB",
                "price": "15.400.000",
            },
            {
                "color": "Đỏ",
                "storage": "128GB",
                "price": "15.500.000",
            },
            {
                "color": "Vàng",
                "storage": "128GB",
                "price": "15.600.000",
            },
            {
                "color": "Xanh",
                "storage": "128GB",
                "price": "15.700.000",
            },
            // {
            //     "color": "Tím",
            //     "storage": "128GB",
            //     "price": "15.800.000",
            // }
        ]
    },
];

function getData() {
    var data = [];

    items.forEach(item => {
        data.push({...item, id: item.name.toLowerCase().split(" ").join("-") });
    });
    return data;
}