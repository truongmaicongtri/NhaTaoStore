var items;

$(document).ready(function() {
    items = getData();


});