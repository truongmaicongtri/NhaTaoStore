var data = [];

function loadDataFromCSV(callback) {
    var dataObjects;
    Papa.parse("http://test.nhataostore.com/csv.csv", {
        download: true,
        header: true,
        complete: function(results) {
            dataObjects = results;
            var item;

            dataObjects.data.forEach(object => {
                if (object.name != "") {
                    if (item) {
                        data.push(item);
                        item = undefined;
                    }
                    item = { name: "", imageUrl: [], category: "", prices: [] };
                    item.name = object.name;
                    item.category = object.category;
                    item.imageUrl.push(object.imageUrl_1);
                    item.imageUrl.push(object.imageUrl_2);
                    item.imageUrl.push(object.imageUrl_3);
                    item.imageUrl.push(object.imageUrl_4);
                } else {
                    item.prices.push({ color: object.color, storage: object.storage, price: object.price });
                }
            });

            callback();
        }
    });
}


function getData(){
    return data;
}